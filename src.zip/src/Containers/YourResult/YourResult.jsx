import './YourResult.css'
import YourResultLeft from '../../Components/YourResultleft';
import YourResultRight from '../../Components/YourResultRight';
import ArrowImage from '../../Assets/Images/ico_art.svg'
const YourResult = () => {
    return (
    <>
    <div className="yr-mainContent"> 
         <div className="yr-leftContent">
            <YourResultLeft />
         </div>
         <div className="yr-rightContent">
         <img className='yr-right-Arrow' src={ArrowImage} alt="ico_art.svg" />
            <YourResultRight />
         </div>
    </div>
    </>
    )
}

export default YourResult;