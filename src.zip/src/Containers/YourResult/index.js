import YourResult from './YourResult'
export default YourResult;