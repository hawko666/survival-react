import Advice from './Advice'
export default Advice;