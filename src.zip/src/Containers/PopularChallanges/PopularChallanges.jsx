import './PopularChallanges.css'
import PopularChallengesLeft from '../../Components/PopularChallengesLeft';
import PopularChallengesRight from '../../Components/PopularChallengesRight'
const PopularChallanges = () => {
    return (
    <>
    
    <div className="pc-mainContent"> 
         <div className="pc-leftContent">
         <div className='pc-header'><p>Popular challenges</p></div>
            <PopularChallengesLeft />
         </div>
         <div className="pc-rightContent">
            <PopularChallengesRight />
         </div>
    </div>
    </>
    )
}

export default PopularChallanges;