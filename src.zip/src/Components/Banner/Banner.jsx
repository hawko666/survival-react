import BannerImage from '../../Assets/Images/img_header.png'
import './Banner.css'
const BannerContainer = () => {
    return (
    <> 
         <div className="s-banner">
            <img className='s-img-banner' src={BannerImage} alt='img_header.png'></img>
         </div>
    </>
    )
}

export default BannerContainer;