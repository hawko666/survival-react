import './YourResultleft.css'
const YourResultleft = () => {
    return (
    <> 
         <div className="sec3-container">
         <div class="yr-left-container">
                <div class="yr-left-content">
                    <h3 class="yr-left-challenge">COMPLETED CHALLENGES</h3>
                    <h3 class="yr-left-no">13</h3>
                    <h3 class="yr-left-text">You have <span class="red">78%</span> chance for survival</h3>
                </div>
                <h3 class="yr-left-rotate-text teko-s-174">YOUR RESULTS</h3>
                <div class="yr-left-card-cross">
                        <i class="fa-solid fa-xmark"></i>
                        <h4 class="yr-left-card-cross-text">SEE MORE</h4>
                </div>
            </div>
         </div>
    </>
    )
}

export default YourResultleft;