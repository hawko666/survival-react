import YourResultleft from './YourResultleft'
export default YourResultleft;