import './FooterColFour.css'
const FooterColFour = () => {
    return (
    <> 
         <div className="yr-banner">
         <div class="footer-advice-container">
                <h3 class="footer-title teko-m-36">Gallery</h3>
                <ul>
                    <li class="footer-text arial-14"><a href="#">Foto gallery</a></li>
                    <li class="footer-text arial-14"><a href="#">Video gallery</a></li>
                </ul>
            </div>
         </div>
    </>
    )
}

export default FooterColFour;