// import PopularChallengesRightShoes from '../../Assets/Images/shoes.png'
import GalleryTwoImage from '../../Assets/Images/Mask Group 6-1.png'
import './GalleryTwo.css'
const GalleryTwo = () => {
    return (
    <> 
         <div className="s-banner">
            {/* <img className='s-img-banner' src={PopularChallengesRightShoes} alt='img_header.png'></img> */}
            <div className="">
            <div class="g-container-tent">
                <div class="g-container-icon"><i class="fa-brands fa-youtube"></i></div>
                <img src={GalleryTwoImage} class="g-container-tent-img" alt="tent"></img>
                <div class="g-container-body">
                    <div class="g-container-date-place">
                        06.08.2019. | SHELTER MAKING
                    </div>
                    <p class="g-container-text">
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                    </p>
                </div>
            </div>
         </div>
         </div>
    </>
    )
}

export default GalleryTwo;