import GalleryTwo from './GalleryTwo'
export default GalleryTwo;