import AdviceRightSliderImg from '../../Assets/Images/Mask Group 4.png'
import './AdviceRight.css'
const AdviceRight = () => {
    return (
    <> 
         <div className="a-main-container">
            <div class="a-right-container-card">
                        <div class="a-right-no-body">
                            <h2 class="a-right-no-big">03</h2>
                            <h3 class="a-right-no-small">03</h3>
                        </div>
                        <img src={AdviceRightSliderImg} class="a-right-camp" alt="camp"></img>
                        <div class="a-right-body ">
                            <h2 class="a-right-title">SURVIVAL MODE</h2>
                            <p class="a-right-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                                sed
                                diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
                                voluptua.
                            </p>
                            <div class="a-right-card-cross">
                                <i class="fa-solid fa-xmark"></i>
                                <h4 class="a-left-card-cross-text">MORE</h4>
                            </div>
                        </div>
            </div>
        </div>
    </>
    )
}

export default AdviceRight;