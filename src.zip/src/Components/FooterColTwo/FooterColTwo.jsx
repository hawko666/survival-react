import './FooterColTwo.css'
const FooterColTwo = () => {
    return (
    <> 
         <div className="footer-inner-wrapper">
         <div class="footer-challenges-container">
                <h3 class="footer-title">CHALLENGES</h3>
                <ul>
                    <li class="footer-text"><a href="#">Endurance</a></li>
                    <li class="footer-text"><a href="#">survival</a></li>
                    <li class="footer-text"><a href="#">Key Skills</a></li>
                    <li class="footer-text"><a href="#">Survival Kits</a></li>
                    <li class="footer-text"><a href="#">Shelter Making</a></li>
                    <li class="footer-text"><a href="#">Food Challenges</a></li>
                </ul>
                <ul class="footer-social-container">
                    <li class="footer-text"><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                    <li class="footer-text"><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                    <li class="footer-text"><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                </ul>
            </div>
         </div>
    </>
    )
}

export default FooterColTwo;