import FooterColTwo from './FooterColTwo'
export default FooterColTwo;