import BannerSide from './BannerSide'
export default BannerSide;