import FooterColOne from './FooterColOne'
export default FooterColOne;