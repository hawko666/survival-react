import './FooterColOne.css'
import FooterFirstColumnimage from '../../Assets/Images/Group 9.svg'
const FooterColOne = () => {
    return (
    <> 
         <div className="Footer-inner-wrapper">
         <div class="footer-logo-container">
                <img src={FooterFirstColumnimage} class="footer-logo-container-img" alt=""></img>
            </div>
         </div>
    </>
    )
}

export default FooterColOne;