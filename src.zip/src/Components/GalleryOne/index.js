import GalleryOne from './GalleryOne'
export default GalleryOne;