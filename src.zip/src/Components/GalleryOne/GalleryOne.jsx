import GalleryOneImage from '../../Assets/Images/Mask Group 6.png'
import './GalleryOne.css'
const GalleryOne = () => {
    return (
    <> 
         <div className="">
            <div class="g-container-tent">
                <div class="g-container-icon"><i class="fa-brands fa-youtube"></i></div>
                <img src={GalleryOneImage} class="g-container-tent-img" alt="tent"></img>
                <div class="g-container-body">
                    <div class="g-container-date-place">
                        06.08.2019. | SHELTER MAKING
                    </div>
                    <p class="g-container-text">
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                    </p>
                </div>
            </div>
         </div>
    </>
    )
}

export default GalleryOne;