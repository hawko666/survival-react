import YourResultRightImage from '../../Assets/Images/Mask Group 2.png'
import YourResultRightSquare from '../../Assets/Images/Rectangle 15.svg'
import './YourResultRight.css'
const YourResultRight = () => {
    return (
    <> 
         <div className="yr-banner">
            <img className='yr-banner-img' src={YourResultRightImage} alt='Mask Group 2.png'></img>
            <img className='yr-banner-img-square' src={YourResultRightSquare} alt='Rectangle 15.svg'></img>
            <div className='yr-text-wrapper'>
            <p className='yr-md-header'>SHARE YOUR RESULTS ON SOCIAL MEDIA</p>
            <p className='yr-sm-header'>Lorem ipsum dolor sit amet, consetetur diam nonumy tempor.</p>
            <div class="sec3-right-card-cross">
                        <i class="fa-solid fa-xmark"></i>
                        <h4 class="sec2-left-card-cross-text">SEE RESULTS FROM YOUR FRIENDS</h4>
                    </div>
            </div>
         </div>
    </>
    )
}

export default YourResultRight;