import YourResultRight from './YourResultRight'
export default YourResultRight;