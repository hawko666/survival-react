import PopularChallengesLeftImage1 from '../../Assets/Images/02.png'
import PopularChallengesLeftImage2 from '../../Assets/Images/03.png'
import './PopularChallengesLeft.css'
const PopularChallengesLeft = () => {
    return (
    <> 
         <div className="pc-right-container">
            <img className='pc-right-img' src={PopularChallengesLeftImage1} alt='PopularChallengesLeftImage1.png'></img>
            <img className='pc-right-img' src={PopularChallengesLeftImage2} alt='PopularChallengesLeftImage2.png'></img>
            <img className='pc-right-img' src={PopularChallengesLeftImage2} alt='PopularChallengesLeftImage2.png'></img>
         </div>
    </>
    )
}

export default PopularChallengesLeft;