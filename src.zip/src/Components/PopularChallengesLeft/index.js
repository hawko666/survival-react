import PopularChallengesLeft from './PopularChallengesLeft'
export default PopularChallengesLeft;