// import PopularChallengesRightShoes from '../../Assets/Images/shoes.png'
import './AdviceLeft.css'
const AdviceLeft = () => {
    return (
    <> 
         <div className="">
         <h3 class="a-left-container-text">ADVICE</h3>
            {/* <img className='s-img-banner' src={PopularChallengesRightShoes} alt='img_header.png'></img> */}
         </div>
    </>
    )
}

export default AdviceLeft;