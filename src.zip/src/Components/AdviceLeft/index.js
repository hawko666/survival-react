import AdviceLeft from './AdviceLeft'
export default AdviceLeft;