import GalleryTopArrow from '../../Assets/Images/ico_art-1.svg'
import './GalleryThree.css'
const GalleryThree = () => {
    return (
    <> 
         <div className="">
            {/* <img className='s-img-banner' src={PopularChallengesRightShoes} alt='img_header.png'></img> */}
            <div class="g-container-gallery">
                <h2 class="g-container-gallery-title">GALLERY</h2>
                <p class="g-container-gallery-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                    sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                </p>
                <div class="g-right-card-cross">
                    <i class="fa-solid fa-xmark"></i>
                    <h4 class="sec2-left-card-cross-text">More</h4>
                </div>
                <a href="#top"><img src={GalleryTopArrow} class="g-container-arrow" alt=""></img></a>
            </div>
         </div>
    </>
    )
}

export default GalleryThree;