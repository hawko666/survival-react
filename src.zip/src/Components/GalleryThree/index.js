import GalleryThree from './GalleryThree'
export default GalleryThree;