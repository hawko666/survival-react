import './FooterColthree.css'
const FooterColthree = () => {
    return (
    <> 
         <div className="footer-innercontainer-three">
         <div class="footer-advice-container">
                <h3 class="footer-title">Advices</h3>
                <ul>
                    <li class="footer-text"><a href="#">Mountain survival</a></li>
                    <li class="footer-text"><a href="#">Forest challenges</a></li>
                    <li class="footer-text"><a href="#">How to make your shelter</a></li>
                    <li class="footer-text"><a href="#">What to eat in forest</a></li>
                    <li class="footer-text"><a href="#">How to stay safe</a></li>
                    <li class="footer-text"><a href="#">What to wear</a></li>
                </ul>
            </div>
         </div>
    </>
    )
}

export default FooterColthree;