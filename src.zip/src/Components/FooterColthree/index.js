import FooterColthree from './FooterColthree'
export default FooterColthree;