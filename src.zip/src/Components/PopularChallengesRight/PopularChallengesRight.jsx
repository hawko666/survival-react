import PopularChallengesRightShoes from '../../Assets/Images/shoes.png';
import PopularChallengesRightShoesShadow from '../../Assets/Images/shadow.png'
import PopularChallengesRightFindMore from '../../Assets/Images/btn_more.png'
import './PopularChallengesRight.css'
const PopularChallengesRight = () => {
    return (
    <> 
         <div className="pc-right-maincontainer">
         <div className='pc-right-img-container'>
            <p className='pc-right-01'>01</p>
            <p className='pc-right-endur'>ENDUR<br/>ANCE</p>
            <img className='pc-img-shoes' src={PopularChallengesRightShoes} alt='img_header.png'></img>
            <img className='pc-img-shoes-shadow' src={PopularChallengesRightShoesShadow} alt='img_header.png'></img>
            <div className='pc-right-text-container'>
            <p className='pc-mission'>Mission</p>
            <p className='pc-medium-para'>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy tempor.</p>
            <p className='pc-small-para'>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
            <img className='pc-img-right-find-more' src={PopularChallengesRightFindMore} alt='btn_more.png'></img>
            </div>
         </div>
         </div>
    </>
    )
}

export default PopularChallengesRight;