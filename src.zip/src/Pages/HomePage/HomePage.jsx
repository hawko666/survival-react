import Header from "../../Containers/Header";
import BannerContainer from "../../Containers/BannerContainer";
import PopularChallanges from "../../Containers/PopularChallanges";
import YourResult from "../../Containers/YourResult";
import Advice from "../../Containers/Advice";
import Gallery from "../../Containers/Gallery";
import Footer from "../../Containers/Footer";
import './HomePage.css'
const HomePage = () => {
    

    return (
        <div>
            <div className="homepage-container">
            <Header/>
            <BannerContainer />
            <PopularChallanges />
            <YourResult />
            <Advice />
            <Gallery />
            </div>
            <Footer />
        </div>
    );
}

export default HomePage;